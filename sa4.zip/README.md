## Stay active: помощник за по-добър, по-щастлив и по-здравословен живот
Ние вярваме в правото за достъпен здравословен начин на живот за всеки и навсякъде, независимо от финансовите възможности и достъпа до фитнес зали.
http://stayactive.vazov-school.com/

## Тестови акаунти
http://stayactive.vazov-school.com/inaction/login
Роля: администратор
Потребител: admin@stayactive.vazov-school.com
Парола: Admin@123456

http://stayactive.vazov-school.com/inaction/login
Роля: потребител
Потребител: user@stayactive.vazov-school.com
Парола: User@123456

http://stayactive.vazov-school.com/inaction/login
Роля: инструктор
Потребител: coach@stayactive.vazov-school.com
Парола: Coach@123456
