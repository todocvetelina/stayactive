<?php echo e($slot); ?>

<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>