<?php $__env->startComponent('boilerplate::card', ['color' => 'warning', 'title' => 'CodeMirror']); ?>
        Usage :
        <pre>&lt;x-boilerplate::codemirror name="code">.color { color: red; }&lt;/x-boilerplate::codemirror></pre>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'boilerplate::components.codemirror','data' => ['name' => 'code']]); ?>
<?php $component->withName('boilerplate::codemirror'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'code']); ?><h1>CodeMirror demo</h1>
<style>
    .color {
        color: red;
    }
</style>
<script>
    $(function () {
        alert('demo');
    });
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php $__env->slot('footer'); ?>
        <div class="small text-muted text-right">
            <a href="https://sebastienheyd.github.io/boilerplate/components/codemirror" target="_blank">component</a> /
            <a href="https://sebastienheyd.github.io/boilerplate/plugins/codemirror" target="_blank">plugin</a> /
            <a href="https://codemirror.net/" target="_blank">CodeMirror</a>
        </div>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate/src/resources/views/plugins/demo/codemirror.blade.php ENDPATH**/ ?>