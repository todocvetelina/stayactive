<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url(config('forum.web.router.prefix'))); ?>"><?php echo e(trans('forum::general.index')); ?></a></li>
        <?php if(isset($category) && $category): ?>
            <?php echo $__env->make('forum::partials.breadcrumb-categories', ['category' => $category], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(isset($thread) && $thread): ?>
            <li class="breadcrumb-item"><a href="<?php echo e(Forum::route('thread.show', $thread)); ?>"><?php echo e($thread->title); ?></a></li>
        <?php endif; ?>
        <?php if(isset($breadcrumbs_append) && count($breadcrumbs_append) > 0): ?>
            <?php $__currentLoopData = $breadcrumbs_append; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="breadcrumb-item"><?php echo e($breadcrumb); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ol>
</nav><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/forum/partials/breadcrumbs.blade.php ENDPATH**/ ?>