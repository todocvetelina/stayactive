<?php if (! $__env->hasRenderedOnce('1b8a32d4-add7-422a-861a-da191ae33d39')): $__env->markAsRenderedOnce('1b8a32d4-add7-422a-861a-da191ae33d39'); ?>
<script src="<?php echo mix('/plugins/moment/moment-with-locales.min.js', '/assets/vendor/boilerplate'); ?>"></script>
<script>moment.locale('<?php echo e(App::getLocale()); ?>')</script>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate/src/resources/views/load/moment.blade.php ENDPATH**/ ?>