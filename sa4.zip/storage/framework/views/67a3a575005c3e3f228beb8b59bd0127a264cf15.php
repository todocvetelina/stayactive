<?php echo $__env->make('boilerplate-media-manager::scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!DOCTYPE html>
<html lang="<?php echo e(App::getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name')); ?></title>
    <?php echo $__env->yieldPushContent('css'); ?>
    <link rel="stylesheet" href="<?php echo e(mix('/plugins/fontawesome/fontawesome.min.css', '/assets/vendor/boilerplate')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('/adminlte.min.css', '/assets/vendor/boilerplate')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('/mediamanager.min.css', '/assets/vendor/boilerplate-media-manager')); ?>">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,300;0,400;0,700;1,400&display=swap" rel="stylesheet">
</head>
<body class="sidebar-mini<?php echo e(setting('darkmode', false) && config('boilerplate.theme.darkmode') ? ' dark-mode accent-light' : ''); ?>">
<div id="disable"></div>
<div class="content-wrapper ml-0">
    <div id="loading">
        <div><span class="fa fa-4x fa-sync-alt fa-spin"></span></div>
    </div>
    <div id="media-content" data-mce="1" data-display="list" data-type="<?php echo e($type); ?>"
         data-path="<?php echo e((string) $path); ?>" data-field="<?php echo e($field); ?>" data-return="<?php echo e($return_type); ?>"
         data-selected="<?php echo e($selected); ?>"></div>
</div>
<script src="<?php echo e(mix('/bootstrap.min.js', '/assets/vendor/boilerplate')); ?>"></script>
<script src="<?php echo e(mix('/admin-lte.min.js', '/assets/vendor/boilerplate')); ?>"></script>
<script src="<?php echo e(mix('/boilerplate.min.js', '/assets/vendor/boilerplate')); ?>"></script>
<script>
    $.ajaxSetup({headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'}});
    bootbox.setLocale('<?php echo e(App::getLocale()); ?>');
    var session = {
        keepalive: "<?php echo e(route('boilerplate.keepalive', null, false)); ?>",
        expire: <?php echo e(time() +  config('session.lifetime') * 60); ?>,
        lifetime:  <?php echo e(config('session.lifetime') * 60); ?>,
        id: "<?php echo e(session()->getId()); ?>"
    }
</script>
<?php echo $__env->yieldPushContent('js'); ?>
</body>

<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate-media-manager/src/resources/views/index-mce.blade.php ENDPATH**/ ?>