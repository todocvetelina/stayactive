<?php if(empty($name)): ?>
    <code>&lt;x-boilerplate-media-manager::file> The name attribute has not been set</code>
<?php else: ?>
<div class="form-group<?php echo e(isset($groupClass) ? ' '.$groupClass : ''); ?>"<?php echo isset($groupId) ? ' id="'.$groupId.'"' : ''; ?>>
    <?php if(!empty($label)): ?>
    <?php echo e(Form::label($name ?? 'file', $label)); ?>

    <?php endif; ?>
    <div class="input-group">
        <div class="input-group-prepend">
            <button type="button" class="btn-select-file btn btn-secondary" data-field="<?php echo e($id); ?>" data-src="<?php echo route('mediamanager.index', ['mce' => true, 'type' => $type ?? 'all', 'return_type' => 'file', 'field' => $id], false); ?>">
                <i class="far fa-folder-open"></i>
            </button>
        </div>
        <input type="text" class="form-control" data-id="text-<?php echo e($id); ?>" value="<?php echo e(preg_replace('/.*\/(.*)\?.*$/', '$1', old($name, $value ?? ''))); ?>" placeholder="<?php echo e(__('boilerplate-media-manager::select.no_file_selected')); ?>" style="background: transparent" disabled>
        <input type="hidden" name="<?php echo e($name); ?>" value="<?php echo e(old($name, $value ?? '')); ?>" data-id="<?php echo e($id); ?>" data-action="setMediaFile"/>
        <button class="btn <?php echo e(old($name, $value ?? false)  ? '' : 'd-none'); ?>" id="clear-<?php echo e($id); ?>" type="button" data-action="clearMediaFile" style="position:absolute;right:0"><span class="fa fa-times"></span></button>
    </div>
<?php if($help ?? false): ?>
    <small class="form-text text-muted"><?php echo app('translator')->get($help); ?></small>
<?php endif; ?>
<?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="error-bubble"><div><?php echo e($message); ?></div></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php echo $__env->make('boilerplate-media-manager::components.async_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate-media-manager/src/resources/views/components/file.blade.php ENDPATH**/ ?>