<div class="list-group-item <?php echo e($thread->pinned ? 'pinned' : ''); ?> <?php echo e($thread->locked ? 'locked' : ''); ?> <?php echo e($thread->trashed() ? 'deleted' : ''); ?>" :class="{ 'border-primary': selectedThreads.includes(<?php echo e($thread->id); ?>) }">
    <div class="row align-items-center text-center">
        <div class="col-sm text-md-start">
            <span class="lead">
                <a href="<?php echo e(Forum::route('thread.show', $thread)); ?>" <?php if(isset($category)): ?>style="color: <?php echo e($category->color); ?>;"<?php endif; ?>><?php echo e($thread->title); ?></a>
            </span>
            <br>
            <?php echo e($thread->authorName); ?> <span class="text-muted"><?php echo $__env->make('forum::partials.timestamp', ['carbon' => $thread->created_at], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>

            <?php if(! isset($category)): ?>
                <br>
                <a href="<?php echo e(Forum::route('category.show', $thread->category)); ?>" style="color: <?php echo e($thread->category->color); ?>;"><?php echo e($thread->category->title); ?></a>
            <?php endif; ?>
        </div>
        <div class="col-sm text-md-end">
            <?php if($thread->pinned): ?>
                <span class="badge rounded-pill bg-info"><?php echo e(trans('forum::threads.pinned')); ?></span>
            <?php endif; ?>
            <?php if($thread->locked): ?>
                <span class="badge rounded-pill bg-warning"><?php echo e(trans('forum::threads.locked')); ?></span>
            <?php endif; ?>
            <?php if($thread->userReadStatus !== null && ! $thread->trashed()): ?>
                <span class="badge rounded-pill bg-success"><?php echo e(trans($thread->userReadStatus)); ?></span>
            <?php endif; ?>
            <?php if($thread->trashed()): ?>
                <span class="badge rounded-pill bg-danger"><?php echo e(trans('forum::general.deleted')); ?></span>
            <?php endif; ?>
            <span class="badge rounded-pill bg-primary" <?php if(isset($category)): ?>style="background: <?php echo e($category->color); ?>;"<?php endif; ?>>
                <?php echo e(trans('forum::general.replies')); ?>: 
                <?php echo e($thread->reply_count); ?>

            </span>
        </div>

        <?php if($thread->lastPost): ?>
            <div class="col-sm text-md-end text-muted">
                <a href="<?php echo e(Forum::route('thread.show', $thread->lastPost)); ?>"><?php echo e(trans('forum::posts.view')); ?> &raquo;</a>
                <br>
                <?php echo e($thread->lastPost->authorName); ?>

                <span class="text-muted"><?php echo $__env->make('forum::partials.timestamp', ['carbon' => $thread->lastPost->created_at], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
            </div>
        <?php endif; ?>

        <?php if(isset($category) && isset($selectableThreadIds) && in_array($thread->id, $selectableThreadIds)): ?>
            <div class="col-sm" style="flex: 0;">
                <input type="checkbox" name="threads[]" :value="<?php echo e($thread->id); ?>" v-model="selectedThreads">
            </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/forum/thread/partials/list.blade.php ENDPATH**/ ?>