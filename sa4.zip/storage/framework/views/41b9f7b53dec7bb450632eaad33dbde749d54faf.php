<?php if (! $__env->hasRenderedOnce('3544a619-43fb-428c-ad43-957935e173dd')): $__env->markAsRenderedOnce('3544a619-43fb-428c-ad43-957935e173dd'); ?>
<?php $__env->startComponent('boilerplate::minify'); ?>
    <script>
        loadScript('<?php echo mix('/plugins/moment/moment-with-locales.min.js', '/assets/vendor/boilerplate'); ?>', () => {
            moment.locale('<?php echo e(App::getLocale()); ?>');
            registerAsset('momentjs');
        });
    </script>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/load/async/moment.blade.php ENDPATH**/ ?>