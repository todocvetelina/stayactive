<?php if (! $__env->hasRenderedOnce('8aae2c03-78b7-4044-b0f2-2c539d858f66')): $__env->markAsRenderedOnce('8aae2c03-78b7-4044-b0f2-2c539d858f66'); ?>
<?php $__env->startComponent('boilerplate::minify'); ?>
    <script>
        loadScript('<?php echo mix('/plugins/moment/moment-with-locales.min.js', '/assets/vendor/boilerplate'); ?>', () => {
            moment.locale('<?php echo e(App::getLocale()); ?>');
            registerAsset('momentjs');
        });
    </script>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate/src/resources/views/load/async/moment.blade.php ENDPATH**/ ?>