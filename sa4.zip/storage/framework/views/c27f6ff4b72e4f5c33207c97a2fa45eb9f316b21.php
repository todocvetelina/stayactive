<?php $__env->startSection('content'); ?>
    <?php echo e(Form::open(['route' => 'boilerplate.recipes.postChoose', 'autocomplete' => 'off'])); ?>

    <div class="row">
        <div class="col-12 mb-3">
            <a href="<?php echo e(route('boilerplate.recipes.index')); ?>" class="btn btn-default" data-toggle="tooltip"
                title="Списък с рецепти">
                <span class="far fa-arrow-alt-circle-left text-muted"></span>
            </a>
            <span class="btn-group float-right">
                <button type="submit" class="btn btn-primary">
                    Запази
                </button>
            </span>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 mb-3 col-md-8 mx-auto">
            <?php $__env->startComponent('boilerplate::card'); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'boilerplate::components.select2','data' => ['name' => 'recipe','label' => 'Рецепта','id' => 'recipe']]); ?>
<?php $component->withName('boilerplate::select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'recipe','label' => 'Рецепта','id' => 'recipe']); ?>
                    <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($recipe->id); ?>"><?php echo e(Str::limit($recipe->title, 60, '...')); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php $__env->startComponent('boilerplate::components.datetimepicker', ['label' => 'Дата', 'name' => 'date', 'appendText' => 'far fa-calendar-alt', 'format' => 'L', 'show-today' => 'true', 'show-close' => 'true', 'value' => now()]); ?><?php echo $__env->renderComponent(); ?>            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('boilerplate::layout.index', [
'title' => 'Добавяне на рецепта към календар',
'subtitle' => 'Добави рецепта',
'breadcrumb' => [
'Добавяне на рецепта към календар' => 'boilerplate.recipes.choose',
]
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/recipes/choose.blade.php ENDPATH**/ ?>