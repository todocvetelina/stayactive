<div class="p-4">
    <div class="alert alert-danger" style="display:flex;align-items:center">
        <span class="fa fa-exclamation-triangle fa-3x" style="margin-right: 10px"></span>
        <span>
            <?php echo e(__('boilerplate-media-manager::error.notfound')); ?><br />
            <a href="<?php echo e(route('mediamanager.index').($query !== '' ? '?'.$query : '')); ?>" style="color: #FFF">
                <?php echo e(__('boilerplate-media-manager::error.back')); ?>

            </a>
        </span>
    </div>
</div><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate-media-manager/src/resources/views/error.blade.php ENDPATH**/ ?>