<?php if (! $__env->hasRenderedOnce('514cdf70-89d3-438e-b9a9-1a51ad14f110')): $__env->markAsRenderedOnce('514cdf70-89d3-438e-b9a9-1a51ad14f110'); ?>
<?php $__env->startPush('plugin-css'); ?>
    <link rel="stylesheet" href="<?php echo mix('/plugins/fullcalendar/main.min.css', '/assets/vendor/boilerplate'); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('plugin-js'); ?>
    <script src="<?php echo mix('/plugins/fullcalendar/fullcalendar.min.js', '/assets/vendor/boilerplate'); ?>"></script>
<?php if(App::getLocale() !== 'en'): ?>
    <script src="<?php echo mix('/plugins/fullcalendar/locales/'.App::getLocale().'.js', '/assets/vendor/boilerplate'); ?>"></script>
    <script>registerAsset('fullCalendar',()=>{$.fn.fullCalendar.options = {locale:"<?php echo e(App::getLocale()); ?>"}})</script>
<?php else: ?>
    <script>registerAsset('fullCalendar')</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/load/fullcalendar.blade.php ENDPATH**/ ?>