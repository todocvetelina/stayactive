<aside class="main-sidebar elevation-<?php echo e(config('boilerplate.theme.sidebar.shadow')); ?>">
    <a href="/" class="brand-link">
        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3">
        </a>
    <div class="sidebar">
        <?php if(config('boilerplate.theme.sidebar.user.visible')): ?>
            <div class="user-panel py-3 d-flex">
                <div class="image">
                    <img src="<?php echo e(Auth::user()->avatar_url); ?>"
                        class="avatar-img img-circle elevation-<?php echo e(config('boilerplate.theme.sidebar.user.shadow')); ?>"
                        alt="<?php echo e(Auth::user()->name); ?>">
                </div>
                <div class="info">
                    <a href="<?php echo e(route('boilerplate.user.profile')); ?>"
                        class="d-block"><?php echo e(Auth::user()->name); ?></a>
                </div>
            </div>
        <?php endif; ?>
        <nav class="mt-3">
            <?php echo $menu; ?>

        </nav>
    </div>
</aside>
<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/layout/mainsidebar.blade.php ENDPATH**/ ?>