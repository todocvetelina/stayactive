<div class="category list-group my-4">
    <div class="list-group-item shadow-sm">
        <div class="row align-items-center text-center">
            <div class="col-sm text-md-start">
                <h5 class="card-title">
                    <a href="<?php echo e(Forum::route('category.show', $category)); ?>" style="color: <?php echo e($category->color); ?>;"><?php echo e($category->title); ?></a>
                </h5>
                <p class="card-text text-muted"><?php echo e($category->description); ?></p>
            </div>
            <div class="col-sm-2 text-md-end">
                <?php if($category->accepts_threads): ?>
                    <span class="badge rounded-pill bg-primary" style="background: <?php echo e($category->color); ?>;">
                        <?php echo e(trans_choice('forum::threads.thread', 2)); ?>: <?php echo e($category->thread_count); ?>

                    </span>
                    <br>
                    <span class="badge rounded-pill bg-primary" style="background: <?php echo e($category->color); ?>;">
                        <?php echo e(trans_choice('forum::posts.post', 2)); ?>: <?php echo e($category->post_count); ?>

                    </span>
                <?php endif; ?>
            </div>
            <div class="col-sm text-md-end text-muted">
                <?php if($category->accepts_threads): ?>
                    <?php if($category->newestThread): ?>
                        <div>
                            <a href="<?php echo e(Forum::route('thread.show', $category->newestThread)); ?>"><?php echo e($category->newestThread->title); ?></a>
                            <?php echo $__env->make('forum::partials.timestamp', ['carbon' => $category->newestThread->created_at], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endif; ?>
                    <?php if($category->latestActiveThread && $category->latestActiveThread->post_count > 1): ?>
                        <div>
                            <a href="<?php echo e(Forum::route('thread.show', $category->latestActiveThread->lastPost)); ?>">Re: <?php echo e($category->latestActiveThread->title); ?></a>
                            <?php echo $__env->make('forum::partials.timestamp', ['carbon' => $category->latestActiveThread->lastPost->created_at], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if($category->children->count() > 0): ?>
        <div class="subcategories">
            <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group-item">
                    <div class="row align-items-center text-center">
                        <div class="col-sm text-md-start">
                            <a href="<?php echo e(Forum::route('category.show', $subcategory)); ?>" style="color: <?php echo e($subcategory->color); ?>;"><?php echo e($subcategory->title); ?></a>
                            <div class="text-muted"><?php echo e($subcategory->description); ?></div>
                        </div>
                        <div class="col-sm-2 text-md-end">
                            <span class="badge rounded-pill bg-primary" style="background: <?php echo e($subcategory->color); ?>;">
                                <?php echo e(trans_choice('forum::threads.thread', 2)); ?>: <?php echo e($subcategory->thread_count); ?>

                            </span>
                            <br>
                            <span class="badge rounded-pill bg-primary" style="background: <?php echo e($subcategory->color); ?>;">
                                <?php echo e(trans_choice('forum::posts.post', 2)); ?>: <?php echo e($subcategory->post_count); ?>

                            </span>
                        </div>
                        <div class="col-sm text-md-end text-muted">
                            <?php if($subcategory->newestThread): ?>
                                <div>
                                    <a href="<?php echo e(Forum::route('thread.show', $subcategory->newestThread)); ?>"><?php echo e($subcategory->newestThread->title); ?></a>
                                    <?php echo $__env->make('forum::partials.timestamp', ['carbon' => $subcategory->newestThread->created_at], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            <?php endif; ?>
                            <?php if($subcategory->latestActiveThread && $subcategory->latestActiveThread->post_count > 1): ?>
                                <div>
                                    <a href="<?php echo e(Forum::route('thread.show', $subcategory->latestActiveThread->lastPost)); ?>">Re: <?php echo e($subcategory->latestActiveThread->title); ?></a>
                                    <?php echo $__env->make('forum::partials.timestamp', ['carbon' => $subcategory->latestActiveThread->lastPost->created_at], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/forum/category/partials/list.blade.php ENDPATH**/ ?>