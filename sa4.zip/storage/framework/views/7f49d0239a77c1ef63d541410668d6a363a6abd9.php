<div class="login-box">
    <div class="login-logo">
       <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
    </div>

    <div class="card">
        <div class="card-body login-card-body">
            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/auth/loginbox.blade.php ENDPATH**/ ?>