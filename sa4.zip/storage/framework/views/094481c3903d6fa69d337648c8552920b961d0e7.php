<?php if(empty($name)): ?>
    <code>&lt;x-boilerplate-media-manager::image> The name attribute has not been set</code>
<?php else: ?>
<div class="form-group<?php echo e(isset($groupClass) ? ' '.$groupClass : ''); ?>"<?php echo isset($groupId) ? ' id="'.$groupId.'"' : ''; ?>>
<?php if(isset($label)): ?>
    <?php echo Form::label($name, __($label)); ?>

<?php endif; ?>
<div class="select-image-wrapper <?php echo e(empty(old($name, $value ?? '')) ? '' : 'editable'); ?>" style="width:<?php echo e($width ?? 300); ?>px;height:<?php echo e($height ?? 200); ?>px">
    <button type="button" style="max-width:<?php echo e($width ?? 300); ?>px;height:<?php echo e($height ?? 200); ?>px" class="btn-select-image" data-field="<?php echo e($id); ?>" data-src="<?php echo route('mediamanager.index', ['mce' => true, 'type' => 'image', 'return_type' => 'image', 'field' => $id], false); ?>">
<?php if(empty(old($name, $value ?? ''))): ?>
        <span class="fa fa-image fa-3x"></span>
<?php else: ?>
        <img src="<?php echo e(old($name, $value ?? '')); ?>" />
<?php endif; ?>
    </button>
    <div class="select-image-menu">
        <button class="btn select-image-view"><span class="fa fa-eye"></span></button>
        <button class="btn select-image-delete"><span class="fa fa-times"></span></button>
    </div>
    <input type="hidden" name="<?php echo e($name); ?>" value="<?php echo e(old($name, $value ?? '')); ?>" data-id="<?php echo e($id); ?>"/>
</div>
<?php if($help ?? false): ?>
    <small class="form-text text-muted"><?php echo app('translator')->get($help); ?></small>
<?php endif; ?>
<?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="error-bubble"><div><?php echo e($message); ?></div></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php echo $__env->make('boilerplate-media-manager::components.async_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate-media-manager/src/resources/views/components/image.blade.php ENDPATH**/ ?>