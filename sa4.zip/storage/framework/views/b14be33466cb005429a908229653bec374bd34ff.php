Column::add(__('<?php echo e($title); ?>'))
                ->width('180px')
                ->data('<?php echo e($field); ?>')
                ->dateFormat(<?php echo $type === 'date' ? '__("boilerplate::date.Ymd")' : ''; ?>),
<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/stubs/columns/date.blade.php ENDPATH**/ ?>