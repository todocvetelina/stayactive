<div id="media-list" class="media-tiles" data-path="<?php echo e($content->path()); ?>">
    <?php if($parent): ?>
        <div class="tile">
            <div class="tile-icon">
                <a href="<?php echo e($parent['link']); ?>" class="link-folder">
                    <span class="fa fa-level-up-alt fa-4x fa-fw media-icon fa-flip-horizontal" ></span>
                </a>
            </div>
            <div class="tile-label">
                <label class="text-center">..</label>
            </div>
        </div>
    <?php endif; ?>
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tile media" data-filename="<?php echo e($item['name']); ?>" data-url="<?php echo e($item['url']); ?>">
            <div class="tile-icon">
                <?php if($item['isDir']): ?>
                    <a href="<?php echo e($item['link']); ?>" class="link-folder">
                        <span class="far fa-folder }} fa-4x fa-fw media-icon"></span>
                    </a>
                <?php else: ?>
                    <a href="<?php echo e($item['url']); ?>" class="link-media" data-filename="<?php echo e($item['name']); ?>">
                        <?php if($item['type'] === 'image'): ?>
                            <img class="lazy" data-src="<?php echo e($item['thumb']); ?>" alt="<?php echo e($item['name']); ?>">
                        <?php else: ?>
                            <span class="fa fa-<?php echo e($item['icon']); ?> fa-5x fa-fw media-icon"></span>
                        <?php endif; ?>
                    </a>
                <?php endif; ?>
            </div>
            <div class="tile-menu">
                <div class="btn-group">
                    <?php if(!$item['isDir']): ?>
                        <a href="<?php echo e($item['url']); ?>" class="btn btn-sm btn-default btn-view">
                            <span class="fa fa-eye"></span>
                        </a>
                        <a href="<?php echo e($item['url']); ?>" class="btn btn-sm btn-default" download="<?php echo e($item['url']); ?>" target="_blank">
                            <span class="fa fa-download"></span>
                        </a>
                    <?php endif; ?>
                    <a href="#" class="btn btn-sm btn-default btn-rename" data-type="<?php echo e($item['type'] === 'folder' ? 'folder' : 'file'); ?>" data-filename="<?php echo e($item['name']); ?>" data-name="<?php echo e($item['filename'] ?? ''); ?>">
                        <span class="fa fa-pencil-alt"></span>
                    </a>
                    <a href="#" class="btn btn-sm btn-default btn-delete" data-filename="<?php echo e($item['name']); ?>">
                        <span class="fa fa-trash"></span>
                    </a>
                </div>
            </div>
            <div class="tile-label">
                <div class="icheck-primary d-inline">
                    <input type="checkbox" name="check[]" value="<?php echo e($item['name']); ?>" id="item_<?php echo e($k); ?>">
                    <label for="item_<?php echo e($k); ?>"><?php echo e($item['name']); ?></label>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate-media-manager/src/resources/views/list-tiles.blade.php ENDPATH**/ ?>