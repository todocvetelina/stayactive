<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-row justify-content-between mb-2">
        <h2 style="color: <?php echo e($category->color); ?>;">
            <?php echo e($category->title); ?> &nbsp;
            <?php if($category->description): ?>
                <small><?php echo e($category->description); ?></small>
            <?php endif; ?>
        </h2>
    </div>

    <div class="v-category-show">
        <div class="clearfix">
            <?php if($category->accepts_threads): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createThreads', $category)): ?>
                    <a href="<?php echo e(Forum::route('thread.create', $category)); ?>" class="btn btn-primary float-end"><?php echo e(trans('forum::threads.new_thread')); ?></a>
                <?php endif; ?>
            <?php endif; ?>

            <div class="btn-group" role="group">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manageCategories')): ?>
                    <button type="button" class="btn btn-secondary" data-open-modal="edit-category">
                        <?php echo e(trans('forum::general.edit')); ?>

                    </button>
                <?php endif; ?>
            </div>
        </div>

        <?php if(! $category->children->isEmpty()): ?>
            <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('forum::category.partials.list', ['category' => $subcategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if($category->accepts_threads): ?>
            <?php if(! $threads->isEmpty()): ?>
                <div class="mt-4">
                    <?php echo e($threads->links('forum::pagination')); ?>

                </div>

                <?php if(count($selectableThreadIds) > 0): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manageThreads', $category)): ?>
                        <form :action="actions[selectedAction]" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" :value="actionMethods[selectedAction]" />

                            <div class="text-end mt-2">
                                <div class="form-check">
                                    <label for="selectAllThreads">
                                        <?php echo e(trans('forum::threads.select_all')); ?>

                                    </label>
                                    <input type="checkbox" value="" id="selectAllThreads" class="align-middle" @click="toggleAll" :checked="selectedThreads.length == selectableThreadIds.length">
                                </div>
                            </div>
                    <?php endif; ?>
                <?php endif; ?>

                <div class="threads list-group my-3 shadow-sm">
                    <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('forum::thread.partials.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if(count($selectableThreadIds) > 0): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manageThreads', $category)): ?>
                            <div class="fixed-bottom-right pb-xs-0 pr-xs-0 pb-sm-3 pr-sm-3 m-2" style="z-index: 1000;">
                                <transition name="fade">
                                    <div class="card text-white bg-secondary shadow-sm" v-if="selectedThreads.length">
                                        <div class="card-header text-center">
                                            <?php echo e(trans('forum::general.with_selection')); ?>

                                        </div>
                                        <div class="card-body">
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <label class="input-group-text" for="bulk-actions"><?php echo e(trans_choice('forum::general.actions', 1)); ?></label>
                                                </div>
                                                <select class="form-select" id="bulk-actions" v-model="selectedAction">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleteThreads', $category)): ?>
                                                        <option value="delete"><?php echo e(trans('forum::general.delete')); ?></option>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('restoreThreads', $category)): ?>
                                                        <option value="restore"><?php echo e(trans('forum::general.restore')); ?></option>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('moveThreadsFrom', $category)): ?>
                                                        <option value="move"><?php echo e(trans('forum::general.move')); ?></option>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lockThreads', $category)): ?>
                                                        <option value="lock"><?php echo e(trans('forum::threads.lock')); ?></option>
                                                        <option value="unlock"><?php echo e(trans('forum::threads.unlock')); ?></option>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pinThreads', $category)): ?>
                                                        <option value="pin"><?php echo e(trans('forum::threads.pin')); ?></option>
                                                        <option value="unpin"><?php echo e(trans('forum::threads.unpin')); ?></option>
                                                    <?php endif; ?>
                                                </select>
                                            </div>

                                            <div class="mb-3" v-if="selectedAction == 'move'">
                                                <label for="category-id"><?php echo e(trans_choice('forum::categories.category', 1)); ?></label>
                                                <select name="category_id" id="category-id" class="form-select">
                                                    <?php echo $__env->make('forum::category.partials.options', ['hide' => $category], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </select>
                                            </div>

                                            <?php if(config('forum.general.soft_deletes')): ?>
                                                <div class="form-check mb-3" v-if="selectedAction == 'delete'">
                                                    <input class="form-check-input" type="checkbox" name="permadelete" value="1" id="permadelete">
                                                    <label class="form-check-label" for="permadelete">
                                                        <?php echo e(trans('forum::general.perma_delete')); ?>

                                                    </label>
                                                </div>
                                            <?php endif; ?>

                                            <div class="text-end">
                                                <button type="submit" class="btn btn-primary" @click="submit" :disabled="selectedAction == null"><?php echo e(trans('forum::general.proceed')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </transition>
                            </div>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            <?php else: ?>
                <div class="card my-3">
                    <div class="card-body">
                        <?php echo e(trans('forum::threads.none_found')); ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createThreads', $category)): ?>
                            <br>
                            <a href="<?php echo e(Forum::route('thread.create', $category)); ?>"><?php echo e(trans('forum::threads.post_the_first')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col col-xs-8">
                    <?php echo e($threads->links('forum::pagination')); ?>

                </div>
                <div class="col col-xs-4 text-end">
                    <?php if($category->accepts_threads): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createThreads', $category)): ?>
                            <a href="<?php echo e(Forum::route('thread.create', $category)); ?>" class="btn btn-primary"><?php echo e(trans('forum::threads.new_thread')); ?></a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <?php if(! $threads->isEmpty()): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('markThreadsAsRead')): ?>
            <div class="text-center mt-3">
                <button class="btn btn-primary px-5" data-open-modal="mark-threads-as-read">
                    <i data-feather="book"></i> <?php echo e(trans('forum::general.mark_read')); ?>

                </button>
            </div>

            <?php echo $__env->make('forum::category.modals.mark-threads-as-read', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manageCategories')): ?>
        <?php echo $__env->make('forum::category.modals.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('forum::category.modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <style>
    .list-group.threads .list-group-item
    {
        border-left-width: 2px;
    }

    .list-group.threads .list-group-item.locked
    {
        border-left-color: var(--bs-yellow);
    }

    .list-group.threads .list-group-item.pinned
    {
        border-left-color: var(--bs-cyan);
    }

    .list-group.threads .list-group-item.deleted
    {
        border-left-color: var(--bs-red);
        opacity: 0.5;
    }
    </style>

    <script>
    new Vue({
        el: '.v-category-show',
        name: 'CategoryShow',
        data: {
            selectableThreadIds: <?php echo json_encode($selectableThreadIds, 15, 512) ?>,
            actions: {
                'delete': "<?php echo e(Forum::route('bulk.thread.delete')); ?>",
                'restore': "<?php echo e(Forum::route('bulk.thread.restore')); ?>",
                'lock': "<?php echo e(Forum::route('bulk.thread.lock')); ?>",
                'unlock': "<?php echo e(Forum::route('bulk.thread.unlock')); ?>",
                'pin': "<?php echo e(Forum::route('bulk.thread.pin')); ?>",
                'unpin': "<?php echo e(Forum::route('bulk.thread.unpin')); ?>",
                'move': "<?php echo e(Forum::route('bulk.thread.move')); ?>"
            },
            actionMethods: {
                'delete': 'DELETE',
                'restore': 'POST',
                'lock': 'POST',
                'unlock': 'POST',
                'pin': 'POST',
                'unpin': 'POST',
                'move': 'POST'
            },
            selectedAction: null,
            selectedThreads: [],
            isEditModalOpen: false,
            isDeleteModalOpen: false
        },
        methods: {
            toggleAll ()
            {
                this.selectedThreads = (this.selectedThreads.length < this.selectableThreadIds.length) ? this.selectableThreadIds : [];
            },
            submit (event)
            {
                if (this.actionMethods[this.selectedAction] === 'DELETE' && ! confirm("<?php echo e(trans('forum::general.generic_confirm')); ?>"))
                {
                    event.preventDefault();
                }
            },
            onClickModal (event)
            {
                if (event.target.classList.contains('modal'))
                {
                    this.isEditModalOpen = false;
                    this.isDeleteModalOpen = false;
                }
            }
        }
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['thread' => null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/forum/category/show.blade.php ENDPATH**/ ?>