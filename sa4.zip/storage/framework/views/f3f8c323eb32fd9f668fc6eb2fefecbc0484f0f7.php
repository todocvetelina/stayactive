<?php echo '<?php'; ?>


namespace App\Datatables;

<?php if($model !== ''): ?>
use <?php echo e($model); ?>;
<?php endif; ?>
use Sebastienheyd\Boilerplate\Datatables\Button;
use Sebastienheyd\Boilerplate\Datatables\Column;
use Sebastienheyd\Boilerplate\Datatables\Datatable;

class <?php echo e($className); ?>Datatable extends Datatable
{
    public $slug = '<?php echo e($slug); ?>';

    public function datasource()
    {
<?php if($model): ?>
        return <?php echo e($shortName); ?>::query();
<?php endif; ?>
    }

    public function setUp()
    {
<?php if($model): ?>
        $this->order('id', 'desc');
<?php endif; ?>
    }

    public function columns(): array
    {
        return [
<?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $column; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            Column::add()
                ->width('20px')
<?php if($model): ?>
                ->actions(function (<?php echo e($shortName); ?> $<?php echo e(strtolower($shortName)); ?>) {
                    return join([
                        // Button::show('<?php echo e(strtolower($shortName)); ?>.show', $<?php echo e(strtolower($shortName)); ?>),
                        // Button::edit('<?php echo e(strtolower($shortName)); ?>.edit', $<?php echo e(strtolower($shortName)); ?>),
                        // Button::delete('<?php echo e(strtolower($shortName)); ?>.destroy', $<?php echo e(strtolower($shortName)); ?>),
                    ]);
                }),
<?php else: ?>
                ->actions(function () {
                    return join([
                        Button::add()->icon('pencil-alt')->color('primary')->make(),
                    ]);
                }),
<?php endif; ?>
        ];
    }
}<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/stubs/datatable.blade.php ENDPATH**/ ?>