<?php $__env->startSection('content'); ?>
    <?php echo e(Form::open(['route' => 'boilerplate.postCalculator', 'autocomplete' => 'off', 'enctype' => 'multipart/form-data'])); ?>

    <div class="row">
        <div class="col-12 mb-3">
            <span class="btn-group float-right">
                <button type="submit" class="btn btn-primary">
                    Запази
                </button>
            </span>
        </div>
    </div>
        

    <div class="row">
        <div class="col-sm-12 mb-3">
            <?php $__env->startComponent('boilerplate::card'); ?>
                <?php $__env->startComponent('boilerplate::input', ['name' => 'weight', 'type' => 'number', 'label' => 'Tегло',  'append-text' => 'килограма', 'autofocus' => true, 'min' => 0]); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('boilerplate::input', ['name' => 'height', 'type' => 'number', 'label' => 'Височина',
                    'append-text' => 'сантиметра', 'min' => 0]); ?>
                <?php echo $__env->renderComponent(); ?>

            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('boilerplate::layout.index', [
'title' => 'Калкулатор (индекс на телесната маса)',
'subtitle' => 'Калкулатор (индекс на телесната маса)',
'breadcrumb' => [
'Калкулатор (индекс на телесната маса)'
]
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/inaction/calculator.blade.php ENDPATH**/ ?>