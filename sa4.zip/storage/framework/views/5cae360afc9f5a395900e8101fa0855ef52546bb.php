<?php if (! $__env->hasRenderedOnce('8f58566e-47ec-437d-9dee-c408dc26a9bc')): $__env->markAsRenderedOnce('8f58566e-47ec-437d-9dee-c408dc26a9bc'); ?>
<?php $__env->startComponent('boilerplate::minify'); ?>
    <?php echo $__env->make('boilerplate::load.async.moment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        loadStylesheet("<?php echo mix('/plugins/datepicker/daterangepicker.min.css', '/assets/vendor/boilerplate'); ?>");
        whenAssetIsLoaded('momentjs', () => {
            loadScript("<?php echo mix('/plugins/datepicker/daterangepicker.min.js', '/assets/vendor/boilerplate'); ?>", () => {
                registerAsset('daterangepicker');
                $.fn.daterangepicker.defaultOptions = {
                    locale: {
                        "applyLabel": "<?php echo app('translator')->get('boilerplate::daterangepicker.applyLabel'); ?>",
                        "cancelLabel": "<?php echo app('translator')->get('boilerplate::daterangepicker.cancelLabel'); ?>",
                        "fromLabel": "<?php echo app('translator')->get('boilerplate::daterangepicker.fromLabel'); ?>",
                        "toLabel": "<?php echo app('translator')->get('boilerplate::daterangepicker.toLabel'); ?>",
                        "customRangeLabel": "<?php echo app('translator')->get('boilerplate::daterangepicker.customRangeLabel'); ?>",
                    }
                };
            });
        });
    </script>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/load/async/daterangepicker.blade.php ENDPATH**/ ?>