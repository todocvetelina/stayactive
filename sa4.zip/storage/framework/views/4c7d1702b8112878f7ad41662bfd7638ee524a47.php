<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-row justify-content-between mb-2">
        <h2 class="flex-grow-1"><?php echo e(trans('forum::general.index')); ?></h2>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('createCategories')): ?>
            <button type="button" class="btn btn-primary" data-open-modal="create-category">
                <?php echo e(trans('forum::categories.create')); ?>

            </button>

            <?php echo $__env->make('forum::category.modals.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('forum::category.partials.list', ['titleClass' => 'lead'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['category' => null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/forum/category/index.blade.php ENDPATH**/ ?>