<?php if (! $__env->hasRenderedOnce('5996e46b-6824-47b7-a0c2-6c113c1edb1d')): $__env->markAsRenderedOnce('5996e46b-6824-47b7-a0c2-6c113c1edb1d'); ?>
<?php $__env->startComponent('boilerplate::minify'); ?>
    <script>
        loadScript('<?php echo e(mix('/plugins/spectrum-colorpicker2/spectrum.min.js', '/assets/vendor/boilerplate')); ?>', () => {
            loadStylesheet('<?php echo e(mix('/plugins/spectrum-colorpicker2/spectrum.min.css', '/assets/vendor/boilerplate')); ?>', () => {
                registerAsset('ColorPicker');
            });
        })
    </script>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/load/async/colorpicker.blade.php ENDPATH**/ ?>