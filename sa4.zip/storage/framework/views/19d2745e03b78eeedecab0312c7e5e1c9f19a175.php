<?php $__env->startSection('content'); ?>
    <div id="create-thread">
        <h2><?php echo e(trans('forum::threads.new_thread')); ?> (<?php echo e($category->title); ?>)</h2>

        <form method="POST" action="<?php echo e(Forum::route('thread.store', $category)); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="title"><?php echo e(trans('forum::general.title')); ?></label>
                <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control">
            </div>

            <div class="mb-3">
                <textarea name="content" class="form-control"><?php echo e(old('content')); ?></textarea>
            </div>

            <div class="text-end">
                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-link"><?php echo e(trans('forum::general.cancel')); ?></a>
                <button type="submit" class="btn btn-primary px-5"><?php echo e(trans('forum::general.create')); ?></button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['breadcrumbs_append' => [trans('forum::threads.new_thread')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/forum/thread/create.blade.php ENDPATH**/ ?>