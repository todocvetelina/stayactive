<?php if (! $__env->hasRenderedOnce('857974ab-f3d6-4dde-9308-d6ee0b159ec4')): $__env->markAsRenderedOnce('857974ab-f3d6-4dde-9308-d6ee0b159ec4'); ?>
<?php $__env->startComponent('boilerplate::minify'); ?>
<script>
    loadStylesheet("<?php echo e(mix('/select-media.min.css', '/assets/vendor/boilerplate-media-manager')); ?>", () => {
        loadScript("<?php echo e(mix('/select-media.min.js', '/assets/vendor/boilerplate-media-manager')); ?>", () => {
            window.selectMediaLocales = {
                confirm: "<?php echo e(__('boilerplate-media-manager::message.deletemedia')); ?>"
            }
        });
    });
</script>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate-media-manager/src/resources/views/components/async_scripts.blade.php ENDPATH**/ ?>