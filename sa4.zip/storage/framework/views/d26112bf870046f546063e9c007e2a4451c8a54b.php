<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mb-3">
            <a href="<?php echo e(route('boilerplate.workouts.index')); ?>" class="btn btn-default" data-toggle="tooltip"
                title="Списък с тренировки">
                <span class="far fa-arrow-alt-circle-left text-muted"></span>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'boilerplate::components.card','data' => []]); ?>
<?php $component->withName('boilerplate::card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="columns">
                    <div class="column is-7">
                        <iframe src="https://www.youtube.com/embed/<?php echo e(explode('?v=', $workout->video)[1]); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
                </iframe>
                <div class="info-box">
                    <span class="info-box-icon bg-info"><i class="far fa-envelope"></i></span>
                    <div class="info-box-content">
                    <span class="info-box-text"><?php echo e($workout->title); ?> <span class="badge bg-secondary"><?php echo e($workout->duration); ?> минути</span>
                     <span class="info-box-number">1,410</span>
                    </div>
                    </div>
                <h2><?php echo e($workout->title); ?> <span class="badge bg-secondary"><?php echo e($workout->duration); ?> минути</span></h2>
                <?php echo $workout->description; ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('boilerplate::layout.index', [
'title' => 'Тренировкa',
'subtitle' => 'Тренировка',
'breadcrumb' => [
'Управление на тренировки' => 'boilerplate.workouts.index',
'Тренировка']
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/workouts/show.blade.php ENDPATH**/ ?>