<?php if (! $__env->hasRenderedOnce('f9216706-179d-4fde-a502-8353d347ccb2')): $__env->markAsRenderedOnce('f9216706-179d-4fde-a502-8353d347ccb2'); ?>
<?php $__env->startPush('plugin-css'); ?>
    <link rel="stylesheet" href="<?php echo mix('/plugins/fileinput/bootstrap-fileinput.min.css', '/assets/vendor/boilerplate'); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('plugin-js'); ?>
    <script src="<?php echo mix('/plugins/fileinput/bootstrap-fileinput.min.js', '/assets/vendor/boilerplate'); ?>"></script>
    <script src="/assets/vendor/boilerplate/plugins/fileinput/themes/fas/theme.min.js"></script>
    <script>$.fn.fileinput.defaults = $.extend({}, $.fn.fileinput.defaults, $.fn.fileinputThemes.fas);</script>
<?php if(App::getLocale() !== 'en'): ?>
    <script src="/assets/vendor/boilerplate/plugins/fileinput/locales/<?php echo e(App::getLocale()); ?>.js"></script>
    <script>$.fn.fileinput.defaults.language='<?php echo e(App::getLocale()); ?>';</script>
<?php endif; ?>
    <script>registerAsset('fileinput');</script>
<?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate/src/resources/views/load/fileinput.blade.php ENDPATH**/ ?>