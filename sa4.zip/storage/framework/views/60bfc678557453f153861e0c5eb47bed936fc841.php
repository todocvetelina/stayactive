<div class="alert alert-<?php echo e($type); ?> alert-dismissable">
    <button type="button" class="btn-close float-end" data-dismiss="alert" aria-hidden="true"></button>
    <div class="message">
        <?php echo $message; ?>

    </div>
</div>
<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/forum/partials/alert.blade.php ENDPATH**/ ?>