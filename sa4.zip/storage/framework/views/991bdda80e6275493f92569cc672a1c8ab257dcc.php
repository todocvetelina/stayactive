<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 mb-3">
            <a href="<?php echo e(route('boilerplate.articles.index')); ?>" class="btn btn-default" data-toggle="tooltip"
                title="Списък със статии">
                <span class="far fa-arrow-alt-circle-left text-muted"></span>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'boilerplate::components.card','data' => []]); ?>
<?php $component->withName('boilerplate::card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <?php if($article->getFirstMediaUrl('featured')): ?>
                <figure class="image">
                    <img src="<?php echo e($article->getFirstMediaUrl('featured', 'thumb')); ?>" alt="">
                </figure>
                <?php endif; ?>
                <h2><?php echo e($article->title); ?></h2>
                <h4><?php echo e($article->subtitle); ?></h4>
                <div class="p-4"><?php echo $article->content; ?></div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('boilerplate::layout.index', [
'title' => 'Статия',
'subtitle' => 'Статия',
'breadcrumb' => [
'Управление на статии' => 'boilerplate.articles.index',
'Статии']
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/inaction/articles/show.blade.php ENDPATH**/ ?>