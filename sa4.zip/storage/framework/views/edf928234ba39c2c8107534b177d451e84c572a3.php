<?php $__env->startSection('content'); ?>
    <div id="edit-post">
        <h2 class="flex-grow-1"><?php echo e(trans('forum::posts.edit')); ?> (<?php echo e($thread->title); ?>)</h2>

        <hr>

        <?php if($post->parent): ?>
            <h3><?php echo e(trans('forum::general.response_to', ['item' => $post->parent->authorName])); ?>...</h3>

            <?php echo $__env->make('forum::post.partials.list', ['post' => $post->parent, 'single' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(Forum::route('post.update', $post)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <div class="mb-3">
                <textarea name="content" class="form-control"><?php echo e(old('content') !== null ? old('content') : $post->content); ?></textarea>
            </div>

            <div class="text-end">
                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-link"><?php echo e(trans('forum::general.cancel')); ?></a>
                <button type="submit" class="btn btn-primary px-5"><?php echo e(trans('forum::general.save')); ?></button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum::master', ['breadcrumbs_append' => [trans('forum::posts.edit')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/forum/post/edit.blade.php ENDPATH**/ ?>