<?php if (! $__env->hasRenderedOnce('0d76c3e5-f054-4a01-b83a-de9ceb98706f')): $__env->markAsRenderedOnce('0d76c3e5-f054-4a01-b83a-de9ceb98706f'); ?>
<script src="<?php echo mix('/plugins/moment/moment-with-locales.min.js', '/assets/vendor/boilerplate'); ?>"></script>
<script>moment.locale('<?php echo e(App::getLocale()); ?>')</script>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/load/moment.blade.php ENDPATH**/ ?>