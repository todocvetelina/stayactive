<?php $__env->startSection('content'); ?>
<?php echo e(Form::open(['route' => ['boilerplate.categories.update', $category->id], 'method' => 'put', 'autocomplete' => 'off'])); ?>

    <div class="row">
        <div class="col-12 mb-3">
            <a href="<?php echo e(route('boilerplate.categories.index')); ?>" class="btn btn-default" data-toggle="tooltip"
                title="Списък с категории">
                <span class="far fa-arrow-alt-circle-left text-muted"></span>
            </a>
            <span class="btn-group float-right">
                <button type="submit" class="btn btn-primary">
                    Запази
                </button>
            </span>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 mb-3">
            <?php $__env->startComponent('boilerplate::card'); ?>
                <?php $__env->startComponent('boilerplate::input', ['name' => 'name', 'label' => 'Име', 'value' => $category->name, 'autofocus' => true]); ?>
                <?php echo $__env->renderComponent(); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('boilerplate::layout.index', [
    'title' => 'Управление на категории',
    'subtitle' => 'Редактирай категория',
    'breadcrumb' => [
        'Управление на категории' => 'boilerplate.workouts.index',
        'Редактирай категория'
    ]
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/categories/edit.blade.php ENDPATH**/ ?>