<?php $__env->startSection('content'); ?>
<?php echo e(Form::open(['route' => ['boilerplate.workouts.update', $workout->id], 'method' => 'put', 'autocomplete' => 'off'])); ?>

    <div class="row">
        <div class="col-12 mb-3">
            <a href="<?php echo e(route('boilerplate.workouts.index')); ?>" class="btn btn-default" data-toggle="tooltip"
                title="Списък с тренировки">
                <span class="far fa-arrow-alt-circle-left text-muted"></span>
            </a>
            <span class="btn-group float-right">
                <button type="submit" class="btn btn-primary">
                    Запази
                </button>
            </span>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 mb-3">
            <?php $__env->startComponent('boilerplate::card'); ?>
                <?php $__env->startComponent('boilerplate::input', ['name' => 'title', 'label' => 'Заглавие', 'value' => $workout->title, 'autofocus' => true]); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'boilerplate::components.tinymce','data' => ['name' => 'description','label' => 'Описание']]); ?>
<?php $component->withName('boilerplate::tinymce'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'description','label' => 'Описание']); ?><?php echo e($workout->description); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                <?php $__env->startComponent('boilerplate::input', ['name' => 'duration', 'type' => 'number', 'label' => 'Продължителност',
                    'append-text' => 'минути', 'value' => $workout->duration, 'min' => 0]); ?>
                <?php echo $__env->renderComponent(); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'boilerplate::components.select2','data' => ['name' => 'category','label' => 'Категория']]); ?>
<?php $component->withName('boilerplate::select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'category','label' => 'Категория']); ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($category->id === $workout->category_id ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php $__env->startComponent('boilerplate::input', ['name' => 'video', 'label' => 'Видео (линк към YouTube)', 'type' => 'url', 'value' => $workout->video]); ?>
                <?php echo $__env->renderComponent(); ?>
                <?php $__env->startComponent('boilerplate::input', ['name' => 'calories_min', 'label' => 'Min калории', 'type' => 'number', 'value' => $workout->calories_min, 'min' => 0]); ?>
                <?php echo $__env->renderComponent(); ?>
                <?php $__env->startComponent('boilerplate::input', ['name' => 'calories_max', 'label' => 'Max калории', 'type' => 'number', 'value' => $workout->calories_max, 'min' => 0]); ?>
                <?php echo $__env->renderComponent(); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('boilerplate::layout.index', [
    'title' => 'Управление на тренировки',
    'subtitle' => 'Редактирай тренировка',
    'breadcrumb' => [
        'Управление на тренировки' => 'boilerplate.workouts.index',
        'Редактирай тренировка'
    ]
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/workouts/edit.blade.php ENDPATH**/ ?>