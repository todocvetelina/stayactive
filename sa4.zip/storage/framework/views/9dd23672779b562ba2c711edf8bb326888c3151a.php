<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(mix('logviewer.min.css', 'assets/vendor/boilerplate')); ?>">
<?php $__env->stopPush(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/logs/style.blade.php ENDPATH**/ ?>