<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div id="calendar"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('boilerplate::load.fullcalendar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        var calendar = $('#calendar').fullCalendar({
            headerToolbar: {
                center: 'addRecipeButton addWorkoutButton',
                right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
            },
            buttonIcons: false,
            navLinks: true,
            editable: true,
            dayMaxEvents: true,
            customButtons: {
                addRecipeButton: {
                    text: 'Добави рецепта',
                    click: function() {
                        window.location.href = "<?php echo e(route('boilerplate.recipes.choose')); ?>";
                    }
                },
                addWorkoutButton: {
                    text: 'Добави тренировка',
                    click: function() {
                        window.location.href = "<?php echo e(route('boilerplate.workouts.choose')); ?>";
                    }
                }
            }
        });

        <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        calendar.addEvent({
            title: '<?php echo e($recipe->title); ?>',
            start: '<?php echo e($recipe->pivot->date); ?>',
            url: '<?php echo e(route('boilerplate.recipes.index')); ?>',
        });

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $workouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        calendar.addEvent({
            title: '<?php echo e($workout->title); ?>',
            start: '<?php echo e($workout->pivot->start_date); ?>',
            end: '<?php echo e($workout->pivot->end_date); ?>',
            url: '<?php echo e(route('boilerplate.workouts.show', $workout->id)); ?>',
            color: 'green'
        });

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('boilerplate::layout.index', [
'title' => 'Табло',
'subtitle' => 'Табло',
'breadcrumb' => ['Табло']]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/dashboard.blade.php ENDPATH**/ ?>