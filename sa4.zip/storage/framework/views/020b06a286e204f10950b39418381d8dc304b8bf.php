<?php $__env->startSection('content'); ?>
    <?php echo e(Form::open(['route' => ['boilerplate.articles.update', $article->id],'method' => 'put','autocomplete' => 'off'])); ?>

    <div class="row">
        <div class="col-12 mb-3">
            <a href="<?php echo e(route('boilerplate.articles.index')); ?>" class="btn btn-default" data-toggle="tooltip"
                title="Списък със статии">
                <span class="far fa-arrow-alt-circle-left text-muted"></span>
            </a>
            <span class="btn-group float-right">
                <button type="submit" class="btn btn-primary">
                    Запази
                </button>
            </span>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 mb-3">
            <?php $__env->startComponent('boilerplate::card'); ?>
                <?php $__env->startComponent('boilerplate::input', ['name' => 'title', 'label' => 'Заглавие', 'value' => $article->title,'autofocus' => true]); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('boilerplate::input', ['name' => 'subtitle', 'label' => 'Подзаглавие', 'value' => $article->subtitle]); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'boilerplate::components.tinymce','data' => ['name' => 'content','label' => 'Съдържание']]); ?>
<?php $component->withName('boilerplate::tinymce'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'content','label' => 'Съдържание']); ?><?php echo e($article->content); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                <?php $__env->startComponent('boilerplate::input', ['name' => 'read_time', 'type' => 'number', 'label' => 'Време за четене',
                    'append-text' => 'минути', 'value' => $article->read_time, 'min' => 0]); ?>
                <?php echo $__env->renderComponent(); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('boilerplate::layout.index', [
'title' => 'Управление на статии',
'subtitle' => 'Редактирай статия',
'breadcrumb' => [
'Управление на статии' => 'boilerplate.workouts.index',
'Редактирай статия'
]
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/articles/edit.blade.php ENDPATH**/ ?>