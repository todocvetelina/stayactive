<footer class="main-footer text-sm">
    <strong>
        &copy; <?php echo e(date('Y')); ?>

        <?php if(config('boilerplate.theme.footer.vendorlink')): ?>
            <a href="<?php echo e(config('boilerplate.theme.footer.vendorlink')); ?>">
                <?php echo config('boilerplate.theme.footer.vendorname'); ?>

            </a>.
        <?php else: ?>
            <?php echo config('boilerplate.theme.footer.vendorname'); ?>.
        <?php endif; ?>
    </strong>
</footer><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/layout/footer.blade.php ENDPATH**/ ?>