<?php if (! $__env->hasRenderedOnce('82380b31-7277-4629-990c-5d036e582bec')): $__env->markAsRenderedOnce('82380b31-7277-4629-990c-5d036e582bec'); ?>
<?php $__env->startComponent('boilerplate::minify'); ?>
    <script>
        loadScript('<?php echo e(mix('/plugins/spectrum-colorpicker2/spectrum.min.js', '/assets/vendor/boilerplate')); ?>', () => {
            loadStylesheet('<?php echo e(mix('/plugins/spectrum-colorpicker2/spectrum.min.css', '/assets/vendor/boilerplate')); ?>', () => {
                registerAsset('ColorPicker');
            });
        })
    </script>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate/src/resources/views/load/async/colorpicker.blade.php ENDPATH**/ ?>