<?php $__env->startComponent('boilerplate::card', ['color' => 'red', 'title' => 'Daterangepicker']); ?>
        Usage
        <pre>&lt;x-boilerplate::daterangepicker name="range" /></pre>
        <div class="row">
            <div class="col-12">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'boilerplate::components.daterangepicker','data' => ['name' => 'test','label' => 'test','minDate' => \Illuminate\Support\Carbon::now()->subDays(30),'maxDate' => \Illuminate\Support\Carbon::now()]]); ?>
<?php $component->withName('boilerplate::daterangepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'test','label' => 'test','min-date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Carbon::now()->subDays(30)),'maxDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Carbon::now())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <!-- Date range -->
                <?php $__env->startComponent('boilerplate::daterangepicker', ['name' => 'range1', 'label' => 'Date range picker', 'appendText' => 'far fa-calendar', 'start' => \Illuminate\Support\Carbon::now()->subDays(10), 'end' => \Illuminate\Support\Carbon::now()]); ?><?php echo $__env->renderComponent(); ?>
            </div>
            <div class="col-6">
                <!-- Date and time range -->
                <?php $__env->startComponent('boilerplate::daterangepicker', ['name' => 'range2', 'label' => 'Date and time range picker', 'appendText' => 'far fa-clock', 'start' => \Illuminate\Support\Carbon::now()->subDays(10)->subHour(), 'end' => \Illuminate\Support\Carbon::now(), 'timePicker' => true]); ?><?php echo $__env->renderComponent(); ?>
            </div>
        </div>
    <?php $__env->slot('footer'); ?>
        <div class="text-right small text-muted">
            <a href="https://sebastienheyd.github.io/boilerplate/components/daterangepicker" target="_blank">component</a> /
            <a href="https://www.daterangepicker.com" target="_blank">Date Range Picker</a>
        </div>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/vendor/sebastienheyd/boilerplate/src/resources/views/plugins/demo/daterangepicker.blade.php ENDPATH**/ ?>