<?php $__env->startSection('content'); ?>
    <h1 class="title is-1"><?php echo e($article->title); ?></h1>
    <h3 class="subtitle"><?php echo e($article->subtitle); ?></h3>
    <div class="columns is-mobile is-multiline has-margin-top-20 has-margin-bottom-20">
        <div class="column is-narrow">
            <span class="icon">
                <i class="far fa-clock"></i>
            </span>
            <span><?php echo e($article->created_at->translatedFormat('j F Y г. G:i')); ?></span>
        </div>
        <div class="column is-narrow">
            <span class="icon">
                <i class="fas fa-book"></i>
            </span>
            <span><?php echo e($article->read_time); ?> минути</span>
        </div>
    </div>
    <?php if($article->getFirstMediaUrl('featured')): ?>
        <div class="columns is-centered">
            <div class="column is-narrow">
                <figure>
                    <img src="<?php echo e($article->getFirstMediaUrl('featured', 'resized')); ?>" alt="">
                </figure>
            </div>
        </div>
    <?php else: ?>
        <div class="hero is-light p-4 is-unselectable">
            <div class="hero-body has-text-grey">
                <div class="container has-text-centered">
                    <span class="icon is-large has-text-black">
                        <i class="fas fa-image fa-lg"></i>
                    </span>
                    <p>
                        Няма изображение!
                    </p>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="content has-margin-top-20"><?php echo $article->content; ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/articles/show.blade.php ENDPATH**/ ?>