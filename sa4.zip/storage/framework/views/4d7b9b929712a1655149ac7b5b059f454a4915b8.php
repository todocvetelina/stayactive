<?php if (! $__env->hasRenderedOnce('076f4ef2-6fcb-4c7d-aee0-696f0f0c1c4c')): $__env->markAsRenderedOnce('076f4ef2-6fcb-4c7d-aee0-696f0f0c1c4c'); ?>
<?php $__env->startPush('plugin-css'); ?>
    <link rel="stylesheet" href="<?php echo mix('/plugins/select2/select2.min.css', '/assets/vendor/boilerplate'); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo mix('/plugins/select2/select2.full.min.js', '/assets/vendor/boilerplate'); ?>"></script>
    <script src="<?php echo mix('/plugins/select2/i18n/'.App::getLocale().'.js', '/assets/vendor/boilerplate'); ?>"></script>
<?php $__env->startComponent('boilerplate::minify'); ?>
    <script>
        registerAsset('select2', () => {
            $.extend(true,$.fn.select2.defaults,{
                language:'<?php echo e(App::getLocale()); ?>',
                direction:'<?php echo app('translator')->get('boilerplate::layout.direction'); ?>'}
            );

            $(document).on('select2:open',(e) => {
                let t = $(e.target);
                if(t && t.length) {
                    let id=t[0].id||t[0].name;
                    document.querySelector(`input[aria-controls*='${id}']`).focus();
                }
            });
        });
    </script>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/load/select2.blade.php ENDPATH**/ ?>