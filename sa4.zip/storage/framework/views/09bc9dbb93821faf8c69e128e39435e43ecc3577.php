Column::add(__('<?php echo e($title); ?>'))
                ->data('<?php echo e($field); ?>'),
<?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/stubs/columns/default.blade.php ENDPATH**/ ?>