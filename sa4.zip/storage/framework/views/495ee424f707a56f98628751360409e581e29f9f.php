<?php if (! $__env->hasRenderedOnce('ca1d0c42-3fdd-4d92-b483-cd82d71cd152')): $__env->markAsRenderedOnce('ca1d0c42-3fdd-4d92-b483-cd82d71cd152'); ?>
<?php $__env->startPush('plugin-css'); ?>
    <link rel="stylesheet" href="<?php echo mix('/plugins/datepicker/datetimepicker.min.css', '/assets/vendor/boilerplate'); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('plugin-js'); ?>
    <?php echo $__env->make('boilerplate::load.moment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo mix('/plugins/datepicker/datetimepicker.min.js', '/assets/vendor/boilerplate'); ?>"></script>
    <?php $__env->startComponent('boilerplate::minify'); ?>
    <script>
        if(! loadedAssets.includes('datetimepicker')) {
            window.loadedAssets.push('datetimepicker');
        }

        $.fn.datetimepicker.Constructor.Default = $.extend({}, $.fn.datetimepicker.Constructor.Default, {
            locale: "<?php echo e(App::getLocale()); ?>",
            icons: $.extend({}, $.fn.datetimepicker.Constructor.Default.icons, {
                time: 'far fa-clock',
                date: 'far fa-calendar',
                up: 'fas fa-arrow-up',
                down: 'fas fa-arrow-down',
                previous: 'fas fa-chevron-left',
                next: 'fas fa-chevron-right',
                today: 'far fa-calendar-check',
                clear: 'fas fa-trash',
                close: 'fas fa-times'
            })
        });
    </script>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH /run/media/thracefields/Data/Workspace/stayactive/resources/views/vendor/boilerplate/load/datepicker.blade.php ENDPATH**/ ?>