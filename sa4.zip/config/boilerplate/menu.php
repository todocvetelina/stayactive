<?php

return [
    'dashboard' => \App\Http\Controllers\Boilerplate\DashboardController::class, // Dashboard controller to use
    'providers' => [],                                                                // Additional menu items providers
];
