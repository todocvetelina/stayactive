<?php

return [
    'user'       => App\Models\Boilerplate\User::class,
    'role'       => App\Models\Boilerplate\Role::class,
    'permission' => App\Models\Boilerplate\Permission::class,
];
